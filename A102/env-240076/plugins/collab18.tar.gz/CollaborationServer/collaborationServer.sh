#!/bin/bash
#
# Start/stop Collaboration Server

SERVICE_NAME='Collaboration Server'
WORK_PATH=$(pwd)
cd "$(dirname $0)"
BASE_PATH=$(pwd)
cd "${WORK_PATH}"
NODE_EXEC='$$NODE_EXEC$$'
LOG_PATH='$$LOG_PATH$$'
CONFIG_JSON="${BASE_PATH}/config.json"
MODULE_PATH="${BASE_PATH}/node_modules/mstr-collab-svc"
COLLAB_PID="${BASE_PATH}/collaborationServer.pid"
# Get the collaboration port in the config.json
# 1. Remove the line break; 2. Remove the dataSource object(it might include the port field)  3. Pick the port number
COLLAB_PORT=$(cat "${CONFIG_JSON}" | tr '\r\n' ' ' | sed 's/"dataSource[^}]*\}//g' | sed -e 's/^.\+"port"[ \t:]\+\([0-9]\+\).\+$/\1/g')SS=$(PATH="$PATH:/sbin:/usr/sbin:/usr/local/sbin:/usr/share/sbin" which ss 2> /dev/null)
[ -z $SS ] && SS=netstat

start() {
    if [ -n "$(check)" ]; then
        echo "${SERVICE_NAME} is already running."
        return
    fi
    $SS -ltn | grep ${COLLAB_PORT} > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "The port ${COLLAB_PORT} is already in use. Aborted." >&2
        exit 1
    fi
    local log_file="${LOG_PATH}/collabsvr_nodejs.log"
    backup_log "${log_file}"
    [ -e "${log_file}" ] && echo >> "${log_file}"
    date '+[%Y.%m.%d %H:%M:%S]' >> "${log_file}"
    NODE_ENV=production nohup "${NODE_EXEC}" "${MODULE_PATH}/server.js" "${CONFIG_JSON}" >> "${log_file}" 2>&1 < /dev/null & echo $! > "${COLLAB_PID}"
    echo "${SERVICE_NAME} is started."
}

stop() {
    local pid="$(check)"
    if [ -z "$pid" ]; then
        echo "${SERVICE_NAME} is not running."
        return
    fi
    kill -SIGINT "$pid"
    $(wait_process_killed "$pid") && kill_process "$(check_node)"
    rm -f "${COLLAB_PID}" > /dev/null 2>&1
}

status() {
    echo -n "${SERVICE_NAME} is "
    [ -n "$(check)" ] && echo "running." || echo "stopped."
}

diagnose() {
    "${NODE_EXEC}" "${MODULE_PATH}/diagnose.js" "${CONFIG_JSON}"
}

backup_log() {
    if [ $# -ne 1 ] || [ ! -e "$1" ] || [ ! -s "$1" ]; then
        return
    fi
    local log_size=$(stat --printf="%s" "${1}")
    if [ $? -eq 0 ] && [ $log_size -gt 20971520 ]; then # log size > 20MB
        mv -f "$1" "${1}.$(date +%Y%m%d%H%M%S -r "$log_file")"
    fi
}

check_node() {
    ps -ef | grep "${CONFIG_JSON}" | grep -v grep | grep "${NODE_EXEC}" | awk 'NR==1{print $2}'
}

check() {
    if [ -f "${COLLAB_PID}" ] && [ -s "${COLLAB_PID}" ]; then
        local pid=$(cat "${COLLAB_PID}")
        ps -fp ${pid} | grep "${CONFIG_JSON}" | grep "${NODE_EXEC}" > /dev/null 2>&1
        [ $? -eq 0 ] && echo "${pid}"
    fi
}

kill_process() {
    for process in $1
    do
        if [ $(ps -p $process | grep -c $process) != '0' ]; then
            kill_one_process $process
        fi
    done
}

kill_one_process() {
    [ -z "$1" ] && return
    kill "$1"
    $(wait_process_killed "$1") && kill -SIGKILL "$1"
}

wait_process_killed() {
    local -i delay=300
    local -i duration=1
    local -i wait_time=0
    while [ $wait_time -le $delay ] && [ $(ps -p $1 | grep -c $1) != '0' ]; do
        sleep $duration > /dev/null 2>&1
        wait_time=${wait_time}+${duration}
        duration=${duration}+5
    done
    echo [ $wait_time -gt $delay ]
}

usage() {
    echo "Usage: $0 {start|stop|restart|status|diagnose}"
    exit 1
}

main() {
    [ $# -gt 2 ] && usage

    case "$1" in
        start|stop|status|diagnose) $1;;
        restart) stop; start;;
        *) usage;;
    esac
}

main "$@"

