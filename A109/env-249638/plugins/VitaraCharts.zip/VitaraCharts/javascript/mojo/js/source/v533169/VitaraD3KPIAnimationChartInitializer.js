mstrmojo.plugins.VitaraCharts = mstrmojo.plugins.VitaraCharts || {};
mstrmojo.plugins.VitaraCharts.v533169 = mstrmojo.plugins.VitaraCharts.v533169 || {};
mstrmojo.plugins.VitaraCharts.v533169.VitaraD3KPIAnimationChartInitializer = mstrmojo.plugins.VitaraCharts.v533169.VitaraD3KPIAnimationChartInitializer || {};mstrmojo.requiresCls('mstrmojo.plugins.VitaraCharts.v533169.34');
mstrmojo.requiresCls('mstrmojo.plugins.VitaraCharts.v533169.33');
mstrmojo.requiresCls('mstrmojo.plugins.VitaraCharts.v533169.35');
mstrmojo.requiresCls('mstrmojo.plugins.VitaraCharts.v533169.VitaraMstrLibs');
mstrmojo.requiresCls('mstrmojo.plugins.VitaraCharts.v533169.272');
mstrmojo.requiresCls('mstrmojo.plugins.VitaraCharts.v533169.89');
